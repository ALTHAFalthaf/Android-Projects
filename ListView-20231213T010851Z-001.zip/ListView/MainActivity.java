package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView MyListView = findViewById(R.id.MyList);

        String items[] = new String[]{"1st item", "2nd item", "3rd item"};
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, items);
        MyListView.setAdapter(myAdapter);
        Toast.makeText(MainActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();

    }
}